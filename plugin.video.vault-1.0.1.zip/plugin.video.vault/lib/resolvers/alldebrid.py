"""
lib/resolvers/alldebrid.py
AllDebrid API resolver.

Flow
----
1. Check if the info_hash is instantly available (cached) via /magnet/instant
2. If cached → upload magnet → get direct link immediately
3. If not cached → upload anyway and poll until ready (background or immediate)
4. Return direct streamable URL

AllDebrid API docs: https://docs.alldebrid.com
"""

import time
import json
import requests
import xbmcaddon
import xbmc

ADDON    = xbmcaddon.Addon('plugin.video.vault')
API_BASE = 'https://api.alldebrid.com/v4'
AGENT    = 'VaultKodi'


def _api(endpoint: str, method='GET', **kwargs):
    key = ADDON.getSetting('alldebrid_key')
    if not key:
        raise ValueError('AllDebrid API key not set')
    params = kwargs.pop('params', {})
    params.update({'agent': AGENT, 'apikey': key})
    url = f'{API_BASE}/{endpoint}'
    try:
        if method == 'POST':
            resp = requests.post(url, params=params, timeout=15, **kwargs)
        else:
            resp = requests.get(url, params=params, timeout=15, **kwargs)
        data = resp.json()
        if data.get('status') != 'success':
            raise RuntimeError(f"AllDebrid error: {data.get('error', {}).get('message', 'unknown')}")
        return data.get('data', {})
    except requests.RequestException as e:
        raise RuntimeError(f'AllDebrid request failed: {e}')


def check_cached(info_hashes: list[str]) -> dict[str, bool]:
    """Return {info_hash: bool} for a list of hashes."""
    if not info_hashes:
        return {}
    try:
        data = _api('magnet/instant', params={'magnets[]': info_hashes})
        result = {}
        for item in data.get('magnets', []):
            h = (item.get('hash') or '').lower()
            result[h] = item.get('instant', False)
        return result
    except Exception as e:
        xbmc.log(f'[Vault] AllDebrid check_cached error: {e}', xbmc.LOGWARNING)
        return {}


def resolve_magnet(magnet: str, info_hash: str = '') -> str:
    """
    Upload a magnet to AllDebrid and return the best direct link.
    Raises RuntimeError if resolution fails.
    """
    # 1. Upload
    data = _api('magnet/upload', method='POST', data={'magnets[]': magnet})
    magnets = data.get('magnets', [])
    if not magnets:
        raise RuntimeError('AllDebrid: no magnet returned after upload')
    magnet_id = magnets[0].get('id')
    if not magnet_id:
        raise RuntimeError('AllDebrid: could not get magnet ID')

    # 2. Poll for ready status (max 60s)
    deadline = time.time() + 60
    while time.time() < deadline:
        status_data = _api('magnet/status', params={'id': magnet_id})
        magnets_status = status_data.get('magnets', [])
        if not magnets_status:
            time.sleep(2)
            continue
        status = magnets_status[0]
        if status.get('statusCode') == 4:  # Ready
            links = status.get('links', [])
            return _pick_best_link(links)
        elif status.get('statusCode') in (5, 6, 7):  # Error states
            raise RuntimeError(f"AllDebrid magnet error: {status.get('status')}")
        time.sleep(3)

    raise RuntimeError('AllDebrid: timed out waiting for magnet to become ready')


def resolve_url(url: str) -> str:
    """Unrestrict a hoster URL (e.g. Rapidgator, 1fichier) via AllDebrid."""
    data = _api('link/unlock', params={'link': url})
    return data.get('link', '')


def _pick_best_link(links: list) -> str:
    """
    Pick the best file from a multi-file torrent.
    Prefers: largest video file by size.
    """
    VIDEO_EXT = ('.mkv', '.mp4', '.avi', '.mov', '.ts', '.m2ts', '.wmv')
    video_links = [
        l for l in links
        if any(l.get('filename', '').lower().endswith(ext) for ext in VIDEO_EXT)
    ]
    if not video_links:
        video_links = links
    if not video_links:
        raise RuntimeError('AllDebrid: no playable links found in torrent')

    # Sort by size descending — biggest file is usually the main feature
    video_links.sort(key=lambda x: x.get('size', 0), reverse=True)
    link_url = video_links[0].get('link', '')
    if not link_url:
        raise RuntimeError('AllDebrid: empty link URL')

    # Unlock the specific file link
    return resolve_url(link_url)


def bulk_check_and_annotate(results) -> list:
    """
    Given a list of LinkResult objects, check AllDebrid cache status in bulk
    and set result.cached = True for hits.  Returns the (mutated) list.
    """
    hashes = [r.info_hash for r in results if r.info_hash]
    if not hashes:
        return results
    cached_map = check_cached(hashes)
    for r in results:
        if r.info_hash and cached_map.get(r.info_hash.lower()):
            r.cached = True
    return results
