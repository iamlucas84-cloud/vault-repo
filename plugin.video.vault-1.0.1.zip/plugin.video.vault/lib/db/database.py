"""
lib/db/database.py
Central SQLite store for Vault Video.

Tables
------
watch_history    — every play event (movie or episode), with progress
watchlist        — titles the user wants to be alerted on
new_episodes     — cache of unseen episodes discovered by the alert service
link_cache       — ranked links cached per title (refreshed daily)
"""

import sqlite3
import time
import os
import xbmcaddon
import xbmc

ADDON    = xbmcaddon.Addon('plugin.video.vault')
_DB_DIR  = xbmc.translatePath(ADDON.getAddonInfo('profile'))
DB_PATH  = os.path.join(_DB_DIR, 'vault.db')

SCHEMA = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS watch_history (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    media_type   TEXT NOT NULL,          -- 'movie' | 'episode'
    tmdb_id      INTEGER NOT NULL,
    title        TEXT NOT NULL,
    season       INTEGER DEFAULT NULL,
    episode      INTEGER DEFAULT NULL,
    progress_pct REAL    DEFAULT 0,      -- 0–100
    duration_s   INTEGER DEFAULT 0,
    position_s   INTEGER DEFAULT 0,
    watched      INTEGER DEFAULT 0,      -- 1 = fully watched
    last_played  INTEGER NOT NULL,       -- unix timestamp
    play_count   INTEGER DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_wh_tmdb ON watch_history(tmdb_id, season, episode);

CREATE TABLE IF NOT EXISTS watchlist (
    tmdb_id      INTEGER PRIMARY KEY,
    media_type   TEXT NOT NULL,
    title        TEXT NOT NULL,
    added_at     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS new_episodes (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    tmdb_id      INTEGER NOT NULL,
    show_title   TEXT NOT NULL,
    season       INTEGER NOT NULL,
    episode      INTEGER NOT NULL,
    air_date     TEXT,
    ep_title     TEXT,
    seen         INTEGER DEFAULT 0,      -- 1 = user has dismissed/watched
    found_at     INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_ne_tmdb ON new_episodes(tmdb_id, season, episode);

CREATE TABLE IF NOT EXISTS link_cache (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    tmdb_id      INTEGER NOT NULL,
    media_type   TEXT NOT NULL,
    season       INTEGER DEFAULT NULL,
    episode      INTEGER DEFAULT NULL,
    link_json    TEXT NOT NULL,          -- JSON list of ranked LinkResult dicts
    scored_at    INTEGER NOT NULL,       -- unix timestamp of last scrape
    expires_at   INTEGER NOT NULL        -- unix timestamp — daily refresh
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_lc_key
    ON link_cache(tmdb_id, media_type, season, episode);
"""


def _connect() -> sqlite3.Connection:
    os.makedirs(_DB_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    conn.commit()
    return conn


class Database:
    """Context-manager wrapper; use as:  with Database() as db:  db.method()"""

    def __enter__(self):
        self._conn = _connect()
        return self

    def __exit__(self, *_):
        self._conn.close()

    # ── Watch History ─────────────────────────────────────────────────────

    def upsert_progress(self, media_type: str, tmdb_id: int, title: str,
                        season=None, episode=None,
                        progress_pct=0.0, duration_s=0, position_s=0,
                        watched=False):
        """Insert or update a play record."""
        now = int(time.time())
        mark_pct = float(ADDON.getSetting('mark_pct') or 80)
        is_watched = int(watched or progress_pct >= mark_pct)
        existing = self._conn.execute(
            "SELECT id, play_count FROM watch_history "
            "WHERE tmdb_id=? AND media_type=? AND season IS ? AND episode IS ?",
            (tmdb_id, media_type, season, episode)
        ).fetchone()
        if existing:
            self._conn.execute(
                "UPDATE watch_history SET progress_pct=?, duration_s=?, position_s=?, "
                "watched=?, last_played=?, play_count=? WHERE id=?",
                (progress_pct, duration_s, position_s, is_watched,
                 now, existing['play_count'] + 1, existing['id'])
            )
        else:
            self._conn.execute(
                "INSERT INTO watch_history "
                "(media_type,tmdb_id,title,season,episode,progress_pct,"
                "duration_s,position_s,watched,last_played,play_count) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,1)",
                (media_type, tmdb_id, title, season, episode,
                 progress_pct, duration_s, position_s, is_watched, now)
            )
        self._conn.commit()

    def get_progress(self, tmdb_id: int, media_type: str,
                     season=None, episode=None) -> dict | None:
        row = self._conn.execute(
            "SELECT * FROM watch_history "
            "WHERE tmdb_id=? AND media_type=? AND season IS ? AND episode IS ?",
            (tmdb_id, media_type, season, episode)
        ).fetchone()
        return dict(row) if row else None

    def get_history(self, media_type=None, limit=100) -> list[dict]:
        if media_type:
            rows = self._conn.execute(
                "SELECT * FROM watch_history WHERE media_type=? "
                "ORDER BY last_played DESC LIMIT ?", (media_type, limit)
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM watch_history ORDER BY last_played DESC LIMIT ?",
                (limit,)
            ).fetchall()
        return [dict(r) for r in rows]

    def is_watched(self, tmdb_id: int, media_type: str,
                   season=None, episode=None) -> bool:
        row = self._conn.execute(
            "SELECT watched FROM watch_history "
            "WHERE tmdb_id=? AND media_type=? AND season IS ? AND episode IS ?",
            (tmdb_id, media_type, season, episode)
        ).fetchone()
        return bool(row and row['watched'])

    # ── Watchlist ─────────────────────────────────────────────────────────

    def add_to_watchlist(self, tmdb_id: int, media_type: str, title: str):
        self._conn.execute(
            "INSERT OR IGNORE INTO watchlist (tmdb_id,media_type,title,added_at) "
            "VALUES (?,?,?,?)",
            (tmdb_id, media_type, title, int(time.time()))
        )
        self._conn.commit()

    def remove_from_watchlist(self, tmdb_id: int):
        self._conn.execute("DELETE FROM watchlist WHERE tmdb_id=?", (tmdb_id,))
        self._conn.commit()

    def in_watchlist(self, tmdb_id: int) -> bool:
        row = self._conn.execute(
            "SELECT 1 FROM watchlist WHERE tmdb_id=?", (tmdb_id,)
        ).fetchone()
        return row is not None

    def get_watchlist(self) -> list[dict]:
        return [dict(r) for r in self._conn.execute(
            "SELECT * FROM watchlist ORDER BY added_at DESC"
        ).fetchall()]

    def get_watched_shows(self) -> list[dict]:
        """TV shows that have been watched at least once — used for alert polling."""
        rows = self._conn.execute(
            "SELECT DISTINCT tmdb_id, title FROM watch_history "
            "WHERE media_type='episode' ORDER BY title"
        ).fetchall()
        return [dict(r) for r in rows]

    # ── New Episode Alerts ────────────────────────────────────────────────

    def add_new_episode(self, tmdb_id: int, show_title: str, season: int,
                        episode: int, air_date: str = '', ep_title: str = ''):
        """Record a newly aired episode (idempotent)."""
        self._conn.execute(
            "INSERT OR IGNORE INTO new_episodes "
            "(tmdb_id,show_title,season,episode,air_date,ep_title,seen,found_at) "
            "VALUES (?,?,?,?,?,?,0,?)",
            (tmdb_id, show_title, season, episode, air_date, ep_title,
             int(time.time()))
        )
        self._conn.commit()

    def get_unseen_episodes(self) -> list[dict]:
        return [dict(r) for r in self._conn.execute(
            "SELECT * FROM new_episodes WHERE seen=0 ORDER BY found_at DESC"
        ).fetchall()]

    def mark_episode_seen(self, episode_id: int):
        self._conn.execute(
            "UPDATE new_episodes SET seen=1 WHERE id=?", (episode_id,)
        )
        self._conn.commit()

    def dismiss_all_alerts(self):
        self._conn.execute("UPDATE new_episodes SET seen=1 WHERE seen=0")
        self._conn.commit()

    # ── Link Cache ────────────────────────────────────────────────────────

    def set_link_cache(self, tmdb_id: int, media_type: str, link_json: str,
                       season=None, episode=None, ttl_hours=24):
        now = int(time.time())
        expires = now + ttl_hours * 3600
        self._conn.execute(
            "INSERT OR REPLACE INTO link_cache "
            "(tmdb_id,media_type,season,episode,link_json,scored_at,expires_at) "
            "VALUES (?,?,?,?,?,?,?)",
            (tmdb_id, media_type, season, episode, link_json, now, expires)
        )
        self._conn.commit()

    def get_link_cache(self, tmdb_id: int, media_type: str,
                       season=None, episode=None) -> str | None:
        now = int(time.time())
        row = self._conn.execute(
            "SELECT link_json FROM link_cache "
            "WHERE tmdb_id=? AND media_type=? AND season IS ? AND episode IS ? "
            "AND expires_at > ?",
            (tmdb_id, media_type, season, episode, now)
        ).fetchone()
        return row['link_json'] if row else None

    def purge_expired_cache(self):
        self._conn.execute(
            "DELETE FROM link_cache WHERE expires_at < ?", (int(time.time()),)
        )
        self._conn.commit()
