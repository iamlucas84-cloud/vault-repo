"""
lib/scrapers/engine.py
Unified scraping engine.  Calls enabled scrapers in parallel, deduplicates,
ranks results by quality, and hands off to the AllDebrid resolver.

Scrapers implemented:
  - Orion (API)
  - Jackett / Prowlarr (RSS / API)
  - Torrentio (public API, no key required)

Each scraper returns a list of RawResult dicts:
  {
    'title':    str,   # release name
    'magnet':   str,   # magnet URI  (preferred)
    'url':      str,   # direct URL  (fallback)
    'info_hash':str,
    'size_gb':  float,
    'seeds':    int,
    'peers':    int,
    'source':   str,   # scraper name
    'cached':   bool,  # known AllDebrid cache hit
  }
"""

import re
import json
import time
import hashlib
import concurrent.futures
from dataclasses import dataclass, field, asdict
from typing import List, Optional

import requests
import xbmcaddon

ADDON = xbmcaddon.Addon('plugin.video.vault')

# ── Quality scoring weights ──────────────────────────────────────────────────

RESOLUTION_SCORE = {'4k': 100, '2160p': 100, '1080p': 80, '720p': 60,
                    '480p': 30, '360p': 10}
CODEC_SCORE = {'hevc': 15, 'x265': 15, 'h265': 15, 'av1': 12,
               'h264': 5, 'x264': 5, 'xvid': 0, 'divx': 0}
HDR_SCORE   = {'hdr10+': 12, 'hdr10': 10, 'hdr': 10, 'dv': 8, 'dolby vision': 8}
SOURCE_SCORE= {'bluray': 20, 'blu-ray': 20, 'bdremux': 18, 'bdrip': 15,
               'webrip': 10, 'web-dl': 12, 'webdl': 12, 'hdtv': 5,
               'dvdrip': 3, 'ts': -50, 'cam': -80, 'hdcam': -40, 'r5': -30}
CACHED_BONUS = 25   # AllDebrid cached = instant play
SEED_SCALE   = 0.03  # per seed, capped at 20 pts


@dataclass
class LinkResult:
    title:      str
    magnet:     str      = ''
    url:        str      = ''
    info_hash:  str      = ''
    size_gb:    float    = 0.0
    seeds:      int      = 0
    peers:      int      = 0
    source:     str      = ''
    cached:     bool     = False
    resolved_url: str    = ''   # filled in by resolver
    score:      int      = 0    # filled in by ranker
    resolution: str      = ''
    codec:      str      = ''
    hdr:        str      = ''

    def to_dict(self): return asdict(self)


# ── Helpers ──────────────────────────────────────────────────────────────────

def _extract_resolution(name: str) -> str:
    name = name.lower()
    for r in ('2160p', '4k', '1080p', '720p', '480p', '360p'):
        if r in name:
            return r
    return ''


def _extract_codec(name: str) -> str:
    name = name.lower()
    for c in ('hevc', 'x265', 'h265', 'av1', 'h264', 'x264', 'xvid', 'divx'):
        if c in name:
            return c
    return ''


def _extract_hdr(name: str) -> str:
    name = name.lower()
    for h in ('hdr10+', 'dolby vision', 'dv', 'hdr10', 'hdr'):
        if h in name:
            return h
    return ''


def _score_link(r: LinkResult) -> int:
    name  = r.title.lower()
    score = 0
    score += RESOLUTION_SCORE.get(r.resolution or _extract_resolution(name), 0)
    score += CODEC_SCORE.get(r.codec or _extract_codec(name), 0)
    score += HDR_SCORE.get(r.hdr or _extract_hdr(name), 0)
    for k, v in SOURCE_SCORE.items():
        if k in name:
            score += v
            break
    score += min(int(r.seeds * SEED_SCALE), 20)
    if r.cached:
        score += CACHED_BONUS
    return score


def _filter_unwanted(results: List[LinkResult]) -> List[LinkResult]:
    filter_cam = ADDON.getSetting('filter_cam') == 'true'
    min_seeds  = int(ADDON.getSetting('min_seeds') or 0)
    clean = []
    for r in results:
        name = r.title.lower()
        if filter_cam and any(x in name for x in (' cam', 'hdcam', ' ts ', 'telesync', 'r5')):
            continue
        if r.seeds < min_seeds and not r.cached:
            continue
        clean.append(r)
    return clean


# ── Individual scrapers ───────────────────────────────────────────────────────

class OrionScraper:
    NAME = 'Orion'

    def scrape(self, query: dict) -> List[LinkResult]:
        key = ADDON.getSetting('orion_api_key')
        if not key:
            return []
        params = {
            'keyapp':  key,
            'keyuser': key,
            'mode':    'stream',
            'action':  'retrieve',
        }
        if query.get('type') == 'movie':
            params.update({'type': 'movie', 'idimdb': query.get('imdb_id', ''),
                           'idtmdb': str(query.get('tmdb_id', ''))})
        else:
            params.update({'type': 'show', 'idtmdb': str(query.get('tmdb_id', '')),
                           'numberseason':  str(query.get('season', 1)),
                           'numberepisode': str(query.get('episode', 1))})
        try:
            resp = requests.get('https://api.orionoid.com', params=params,
                                timeout=int(ADDON.getSetting('scrape_timeout') or 20))
            data = resp.json()
            streams = data.get('data', {}).get('streams', [])
            out = []
            for s in streams:
                video = s.get('video', {})
                file_ = s.get('file', {})
                out.append(LinkResult(
                    title=s.get('file', {}).get('name', 'Orion result'),
                    magnet=file_.get('magnet', ''),
                    url=file_.get('url', ''),
                    info_hash=file_.get('hash', ''),
                    size_gb=round(file_.get('size', 0) / 1073741824, 2),
                    seeds=s.get('stream', {}).get('seeds', 0),
                    peers=s.get('stream', {}).get('peers', 0),
                    source=self.NAME,
                    resolution=video.get('quality', ''),
                    codec=video.get('codec', ''),
                ))
            return out
        except Exception as e:
            import xbmc; xbmc.log(f'[Vault] Orion error: {e}', xbmc.LOGWARNING)
            return []


class JackettScraper:
    NAME = 'Jackett'

    def scrape(self, query: dict) -> List[LinkResult]:
        url  = ADDON.getSetting('jackett_url').rstrip('/')
        key  = ADDON.getSetting('jackett_api_key')
        if not url or not key:
            return []
        search_query = query.get('title', '')
        if query.get('type') == 'episode':
            s = str(query.get('season', 1)).zfill(2)
            e = str(query.get('episode', 1)).zfill(2)
            search_query += f' S{s}E{e}'
        try:
            resp = requests.get(
                f'{url}/api/v2.0/indexers/all/results',
                params={'apikey': key, 'Query': search_query},
                timeout=int(ADDON.getSetting('scrape_timeout') or 20)
            )
            data = resp.json()
            out = []
            for item in data.get('Results', []):
                out.append(LinkResult(
                    title=item.get('Title', ''),
                    magnet=item.get('MagnetUri', ''),
                    url=item.get('Link', ''),
                    info_hash=item.get('InfoHash', ''),
                    size_gb=round(item.get('Size', 0) / 1073741824, 2),
                    seeds=item.get('Seeders', 0),
                    peers=item.get('Peers', 0),
                    source=self.NAME,
                ))
            return out
        except Exception as e:
            import xbmc; xbmc.log(f'[Vault] Jackett error: {e}', xbmc.LOGWARNING)
            return []


class TorrentioScraper:
    """
    Torrentio public Stremio add-on endpoint — no API key required.
    Provides well-seeded, popular results and is great for mainstream content.
    """
    NAME = 'Torrentio'
    BASE = 'https://torrentio.strem.fun'

    def scrape(self, query: dict) -> List[LinkResult]:
        media_type = query.get('type', 'movie')
        imdb_id    = query.get('imdb_id', '')
        if not imdb_id:
            return []
        if media_type == 'movie':
            path = f'/stream/movie/{imdb_id}.json'
        else:
            s = query.get('season', 1)
            e = query.get('episode', 1)
            path = f'/stream/series/{imdb_id}:{s}:{e}.json'
        try:
            resp = requests.get(f'{self.BASE}{path}',
                                timeout=int(ADDON.getSetting('scrape_timeout') or 20))
            data = resp.json()
            out = []
            for item in data.get('streams', []):
                name = item.get('name', '') + ' ' + item.get('title', '')
                info_hash = ''
                magnet    = ''
                bhv = item.get('infoHash', '')
                if bhv:
                    info_hash = bhv
                    magnet = (f'magnet:?xt=urn:btih:{bhv}'
                              f'&dn={requests.utils.quote(name)}')
                seeds = 0
                m = re.search(r'👤\s*(\d+)', item.get('title', ''))
                if m:
                    seeds = int(m.group(1))
                out.append(LinkResult(
                    title=name.strip(),
                    magnet=magnet,
                    url=item.get('url', ''),
                    info_hash=info_hash,
                    seeds=seeds,
                    source=self.NAME,
                ))
            return out
        except Exception as e:
            import xbmc; xbmc.log(f'[Vault] Torrentio error: {e}', xbmc.LOGWARNING)
            return []


# ── Main engine ──────────────────────────────────────────────────────────────

SCRAPERS = {
    'orion':     OrionScraper,
    'jackett':   JackettScraper,
    'torrentio': TorrentioScraper,
}


def scrape(query: dict) -> List[LinkResult]:
    """
    Run all enabled scrapers in parallel.
    query dict keys:
      type        'movie' | 'episode'
      tmdb_id     int
      imdb_id     str  (e.g. 'tt1234567')
      title       str
      year        str  (movies only)
      season      int  (episodes only)
      episode     int  (episodes only)
    Returns a list of LinkResult sorted by score descending.
    """
    enabled = []
    for name, cls in SCRAPERS.items():
        if ADDON.getSetting(f'scraper_{name}') == 'true':
            enabled.append(cls())

    all_results: List[LinkResult] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(enabled) or 1) as ex:
        futures = {ex.submit(s.scrape, query): s.NAME for s in enabled}
        for fut in concurrent.futures.as_completed(futures):
            try:
                all_results.extend(fut.result())
            except Exception as e:
                import xbmc
                xbmc.log(f'[Vault] Scraper {futures[fut]} exception: {e}',
                         xbmc.LOGWARNING)

    # Deduplicate by info_hash (keep highest-seeded copy)
    seen: dict[str, LinkResult] = {}
    for r in all_results:
        key = r.info_hash or hashlib.md5(r.title.encode()).hexdigest()
        if key not in seen or r.seeds > seen[key].seeds:
            seen[key] = r

    unique = list(seen.values())

    # Decorate with parsed metadata
    for r in unique:
        if not r.resolution: r.resolution = _extract_resolution(r.title)
        if not r.codec:      r.codec      = _extract_codec(r.title)
        if not r.hdr:        r.hdr        = _extract_hdr(r.title)

    # Filter
    filtered = _filter_unwanted(unique)

    # Score & sort
    for r in filtered:
        r.score = _score_link(r)

    prefer_cached = ADDON.getSetting('prefer_cached') == 'true'
    filtered.sort(key=lambda r: (r.cached if prefer_cached else 0, r.score),
                  reverse=True)

    max_results = int(ADDON.getSetting('max_results') or 50)
    return filtered[:max_results]
