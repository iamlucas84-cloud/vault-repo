"""
lib/scrapers/anime_engine.py
Anime-specific scraping engine.

Sources
-------
1. Otaku (AnimeTosho)   — Usenet/torrent index, best quality, like "Otaku" addon
2. Nyaa.si             — Premier anime torrent tracker (no key needed)
3. SubsPlease          — Seasonal simulcast releases (best freshness)
4. AnimeTosho          — Mirror search, Usenet + torrent
5. Nixtoons2-style      — Direct stream scraping from anime streaming sites

All sources feed into the same AllDebrid resolver used for Movies/TV.
Direct stream sources (Nixtoons2-style) can play without AllDebrid if the
URL is already an m3u8/mp4 direct link.
"""

import re
import json
import hashlib
import concurrent.futures
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field, asdict
from typing import List, Optional

import requests
import xbmcaddon
import xbmc

ADDON = xbmcaddon.Addon('plugin.video.vault')

SESSION = requests.Session()
SESSION.headers.update({
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                   'AppleWebKit/537.36 (KHTML, like Gecko) '
                   'Chrome/120.0.0.0 Safari/537.36')
})


@dataclass
class AnimeLink:
    title:        str
    magnet:       str      = ''
    url:          str      = ''       # direct stream or hoster URL
    info_hash:    str      = ''
    size_gb:      float    = 0.0
    seeds:        int      = 0
    peers:        int      = 0
    source:       str      = ''
    cached:       bool     = False
    resolved_url: str      = ''
    score:        int      = 0
    resolution:   str      = ''
    sub_type:     str      = ''       # 'sub' | 'dub' | 'raw'
    is_direct:    bool     = False    # True = no resolver needed

    def to_dict(self): return asdict(self)


# ── Scoring ───────────────────────────────────────────────────────────────────

RES_SCORE = {'1080p': 80, '720p': 60, '480p': 30, '360p': 10}
CACHED_BONUS = 25
GROUP_BONUS = {
    'subsplease': 10, 'erai-raws': 8, 'ember': 8,
    'judas': 7, 'snowr': 6, 'horriblesubsplus': 5,
}


def _score(r: AnimeLink) -> int:
    name  = r.title.lower()
    score = RES_SCORE.get(r.resolution or _res(name), 0)
    score += min(int(r.seeds * 0.05), 20)
    for grp, pts in GROUP_BONUS.items():
        if grp in name:
            score += pts
            break
    if r.cached:
        score += CACHED_BONUS
    if 'blu-ray' in name or 'bluray' in name or 'bd' in name:
        score += 15
    if r.sub_type == 'dub' and ADDON.getSetting('anime_prefer_dub') == 'true':
        score += 10
    return score


def _res(name: str) -> str:
    for r in ('1080p', '720p', '480p', '360p'):
        if r in name:
            return r
    return ''


def _sub_type(name: str) -> str:
    name = name.lower()
    if 'dub' in name or 'dubbed' in name:
        return 'dub'
    if 'raw' in name:
        return 'raw'
    return 'sub'


# ── Nyaa.si scraper (RSS — no API key needed) ─────────────────────────────────

class NyaaScraper:
    NAME = 'Nyaa'
    RSS  = 'https://nyaa.si/?page=rss'

    def scrape(self, query: dict) -> List[AnimeLink]:
        search = _build_search(query)
        try:
            r = SESSION.get(self.RSS, params={'q': search, 'c': '1_2', 'f': '0'},
                            timeout=int(ADDON.getSetting('scrape_timeout') or 20))
            root = ET.fromstring(r.content)
            ns   = {'nyaa': 'https://nyaa.si/xmlns/nyaa'}
            out  = []
            for item in root.findall('.//item'):
                title = item.findtext('title') or ''
                link  = item.findtext('link') or ''
                magnet = ''
                for tag in item:
                    if tag.tag.endswith('magnetUri'):
                        magnet = tag.text or ''
                        break
                # Info hash from magnet
                info_hash = ''
                m = re.search(r'btih:([a-fA-F0-9]+)', magnet)
                if m:
                    info_hash = m.group(1).lower()
                seeds = 0
                for tag in item:
                    if tag.tag.endswith('seeders'):
                        try: seeds = int(tag.text or 0)
                        except: pass
                size_gb = 0.0
                for tag in item:
                    if tag.tag.endswith('size'):
                        try:
                            size_gb = round(int(tag.text or 0) / 1073741824, 2)
                        except: pass
                res = _res(title.lower())
                out.append(AnimeLink(
                    title=title, magnet=magnet, url=link,
                    info_hash=info_hash, size_gb=size_gb,
                    seeds=seeds, source=self.NAME,
                    resolution=res, sub_type=_sub_type(title),
                ))
            return out
        except Exception as e:
            xbmc.log(f'[Vault/Anime] Nyaa error: {e}', xbmc.LOGWARNING)
            return []


# ── SubsPlease (seasonal simulcasts via Nyaa RSS filtered feed) ───────────────

class SubsPleaseScraper:
    NAME = 'SubsPlease'
    RSS  = 'https://subsplease.org/rss/?t&r=1080'

    def scrape(self, query: dict) -> List[AnimeLink]:
        """Only useful for currently-airing shows. Returns latest batches."""
        search_title = query.get('title', '').lower()
        ep_str = ''
        if query.get('episode'):
            ep_str = f'{int(query["episode"]):02d}'
        try:
            r = SESSION.get(self.RSS, timeout=15)
            root = ET.fromstring(r.content)
            out  = []
            for item in root.findall('.//item'):
                title = item.findtext('title') or ''
                tl    = title.lower()
                # Basic title match
                if search_title and not _fuzzy_match(search_title, tl):
                    continue
                if ep_str and ep_str not in title:
                    continue
                link   = item.findtext('link') or ''
                magnet = ''
                for tag in item:
                    if tag.tag.endswith('magnetUri') or 'magnet' in tag.tag.lower():
                        magnet = tag.text or ''
                        break
                info_hash = ''
                m = re.search(r'btih:([a-fA-F0-9]+)', magnet)
                if m:
                    info_hash = m.group(1).lower()
                out.append(AnimeLink(
                    title=title, magnet=magnet, url=link,
                    info_hash=info_hash, seeds=20,  # SubsPlease is always well-seeded
                    source=self.NAME, resolution='1080p',
                    sub_type='sub',
                ))
            return out
        except Exception as e:
            xbmc.log(f'[Vault/Anime] SubsPlease error: {e}', xbmc.LOGWARNING)
            return []


# ── AnimeTosho (Usenet + torrent index) ───────────────────────────────────────

class AnimeToshoScraper:
    NAME = 'AnimeTosho'
    API  = 'https://feed.animetosho.org/api'

    def scrape(self, query: dict) -> List[AnimeLink]:
        search = _build_search(query)
        try:
            r = SESSION.get(self.API,
                            params={'q': search, 'order': 'seeders-d',
                                    'qx': 1},
                            timeout=int(ADDON.getSetting('scrape_timeout') or 20))
            items = r.json()
            out   = []
            for item in (items if isinstance(items, list) else []):
                title   = item.get('title', '')
                magnet  = item.get('magnet_uri', '')
                torrent = item.get('torrent_url', '')
                info_hash = item.get('info_hash', '')
                size_gb = round(item.get('total_size', 0) / 1073741824, 2)
                seeds   = item.get('seeders', 0)
                res     = _res(title.lower())
                out.append(AnimeLink(
                    title=title, magnet=magnet,
                    url=torrent or item.get('link', ''),
                    info_hash=info_hash.lower(),
                    size_gb=size_gb, seeds=seeds,
                    source=self.NAME, resolution=res,
                    sub_type=_sub_type(title),
                ))
            return out
        except Exception as e:
            xbmc.log(f'[Vault/Anime] AnimeTosho error: {e}', xbmc.LOGWARNING)
            return []


# ── Nixtoons2-style direct stream scraper ─────────────────────────────────────
# Scrapes anime streaming sites for direct m3u8/mp4 links.
# These play directly without AllDebrid — instant and reliable for streaming-only shows.

class DirectStreamScraper:
    """
    Queries Zoro.to (now Aniwatch.to) and 9Anime-compatible APIs
    for direct stream links.  Returns m3u8/mp4 URLs as AnimeLink items
    with is_direct=True.

    Falls back gracefully — if the site is unavailable, returns [].
    """
    NAME = 'DirectStream'

    # Aniwatch (Zoro replacement) uses an unofficial API
    ANIWATCH_BASE = 'https://aniwatch-api.vercel.app'

    def scrape(self, query: dict) -> List[AnimeLink]:
        title   = query.get('title', '')
        episode = query.get('episode', 1)
        out     = []

        # Try Aniwatch API
        try:
            out.extend(self._scrape_aniwatch(title, int(episode)))
        except Exception as e:
            xbmc.log(f'[Vault/Anime] Aniwatch error: {e}', xbmc.LOGWARNING)

        return out

    def _scrape_aniwatch(self, title: str, episode: int) -> List[AnimeLink]:
        # Search
        r = SESSION.get(f'{self.ANIWATCH_BASE}/api/v2/hianime/search',
                        params={'q': title, 'page': 1}, timeout=10)
        data  = r.json()
        animes = (data.get('data', {}).get('animes') or [])
        if not animes:
            return []

        # Pick closest title match
        best = _best_title_match(title, animes,
                                  key=lambda a: a.get('name', ''))
        if not best:
            return []

        anime_id = best.get('id', '')
        if not anime_id:
            return []

        # Get episode list
        ep_r = SESSION.get(
            f'{self.ANIWATCH_BASE}/api/v2/hianime/anime/{anime_id}/episodes',
            timeout=10
        )
        ep_data = ep_r.json()
        episodes = ep_data.get('data', {}).get('episodes', [])
        if not episodes or episode > len(episodes):
            return []

        ep_entry = episodes[episode - 1]
        ep_id    = ep_entry.get('episodeId', '')
        if not ep_id:
            return []

        # Get stream sources
        src_r = SESSION.get(
            f'{self.ANIWATCH_BASE}/api/v2/hianime/episode/sources',
            params={'animeEpisodeId': ep_id, 'server': 'hd-1', 'category': 'sub'},
            timeout=10
        )
        src_data = src_r.json()
        sources  = src_data.get('data', {}).get('sources', [])

        out = []
        for src in sources:
            stream_url = src.get('url', '')
            quality    = str(src.get('quality', ''))
            if not stream_url:
                continue
            res = '1080p' if '1080' in quality else '720p' if '720' in quality else ''
            out.append(AnimeLink(
                title=f'{title} E{episode:02d} [{quality}] [Sub] [DirectStream]',
                url=stream_url,
                source=f'{self.NAME}/Aniwatch',
                resolution=res,
                sub_type='sub',
                is_direct=True,
                seeds=999,   # Direct streams always "available"
            ))

        # Also try dub
        try:
            dub_r = SESSION.get(
                f'{self.ANIWATCH_BASE}/api/v2/hianime/episode/sources',
                params={'animeEpisodeId': ep_id, 'server': 'hd-1', 'category': 'dub'},
                timeout=8
            )
            dub_sources = dub_r.json().get('data', {}).get('sources', [])
            for src in dub_sources:
                stream_url = src.get('url', '')
                quality    = str(src.get('quality', ''))
                if not stream_url:
                    continue
                res = '1080p' if '1080' in quality else '720p'
                out.append(AnimeLink(
                    title=f'{title} E{episode:02d} [{quality}] [Dub] [DirectStream]',
                    url=stream_url,
                    source=f'{self.NAME}/Aniwatch',
                    resolution=res,
                    sub_type='dub',
                    is_direct=True,
                    seeds=999,
                ))
        except Exception:
            pass

        return out


# ── Query builder ─────────────────────────────────────────────────────────────

def _build_search(query: dict) -> str:
    title = query.get('title', '')
    ep    = query.get('episode')
    if ep:
        ep_int = int(ep)
        return f'{title} {ep_int:02d}'
    return title


def _fuzzy_match(needle: str, haystack: str) -> bool:
    """Very simple word-overlap match for title filtering."""
    words = [w for w in needle.split() if len(w) > 2]
    if not words:
        return True
    return sum(1 for w in words if w in haystack) >= max(1, len(words) // 2)


def _best_title_match(target: str, items: list, key) -> dict | None:
    target = target.lower()
    scored = []
    for item in items:
        name   = key(item).lower()
        words  = target.split()
        hits   = sum(1 for w in words if w in name)
        scored.append((hits, item))
    scored.sort(key=lambda x: x[0], reverse=True)
    return scored[0][1] if scored and scored[0][0] > 0 else (items[0] if items else None)


# ── Main engine ───────────────────────────────────────────────────────────────

ANIME_SCRAPERS = {
    'nyaa':         NyaaScraper,
    'subsplease':   SubsPleaseScraper,
    'animetosho':   AnimeToshoScraper,
    'directstream': DirectStreamScraper,
}


def scrape_anime(query: dict) -> List[AnimeLink]:
    """
    query dict keys:
      title    str   — anime title (English preferred)
      mal_id   int   — MyAnimeList ID
      episode  int   — episode number (1-based)
      type     str   — 'series' | 'movie'

    Returns ranked AnimeLink list.
    """
    enabled = []
    for name, cls in ANIME_SCRAPERS.items():
        setting_key = f'anime_scraper_{name}'
        # Default to enabled if setting not explicitly set to false
        if ADDON.getSetting(setting_key) != 'false':
            enabled.append(cls())

    all_results: List[AnimeLink] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(enabled) or 1) as ex:
        futures = {ex.submit(s.scrape, query): s.NAME for s in enabled}
        for fut in concurrent.futures.as_completed(futures):
            try:
                all_results.extend(fut.result())
            except Exception as e:
                xbmc.log(f'[Vault/Anime] Scraper exception: {e}', xbmc.LOGWARNING)

    # Deduplicate by info_hash (keep highest-seeded); direct streams always kept
    seen: dict[str, AnimeLink] = {}
    direct = [r for r in all_results if r.is_direct]
    torrent = [r for r in all_results if not r.is_direct]

    for r in torrent:
        key = r.info_hash or hashlib.md5(r.title.encode()).hexdigest()
        if key not in seen or r.seeds > seen[key].seeds:
            seen[key] = r

    unique = direct + list(seen.values())

    # Score & sort — direct streams first (instant), then by score
    for r in unique:
        if not r.resolution:
            r.resolution = _res(r.title.lower())
        r.score = _score(r)

    unique.sort(key=lambda r: (r.is_direct, r.cached, r.score), reverse=True)

    max_results = int(ADDON.getSetting('max_results') or 50)
    return unique[:max_results]
