"""
lib/ui/anime_metadata.py
Anime metadata via:
  - Jikan v4  (unofficial MyAnimeList REST API — no key required)
  - AniList   (GraphQL — no key required for public data)

Returns dicts with Kodi-compatible info labels.
Covers: seasonal anime, popular, search, episode lists, genres.
"""

import requests
import xbmc

_SESSION = requests.Session()
_SESSION.headers.update({'User-Agent': 'VaultKodi/1.0'})
_CACHE: dict = {}

JIKAN_BASE  = 'https://api.jikan.moe/v4'
ANILIST_URL = 'https://graphql.anilist.co'

IMG_PLACEHOLDER = 'https://via.placeholder.com/300x450?text=No+Image'


def _jikan(path: str, **params) -> dict:
    key = path + str(sorted(params.items()))
    if key in _CACHE:
        return _CACHE[key]
    try:
        r = _SESSION.get(f'{JIKAN_BASE}{path}', params=params, timeout=10)
        r.raise_for_status()
        data = r.json()
        _CACHE[key] = data
        return data
    except Exception as e:
        xbmc.log(f'[Vault/Anime] Jikan error {path}: {e}', xbmc.LOGWARNING)
        return {}


def _anilist(query: str, variables: dict) -> dict:
    key = query[:60] + str(sorted(variables.items()))
    if key in _CACHE:
        return _CACHE[key]
    try:
        r = _SESSION.post(ANILIST_URL,
                          json={'query': query, 'variables': variables},
                          timeout=10)
        r.raise_for_status()
        data = r.json().get('data', {})
        _CACHE[key] = data
        return data
    except Exception as e:
        xbmc.log(f'[Vault/Anime] AniList error: {e}', xbmc.LOGWARNING)
        return {}


# ── Jikan helpers ─────────────────────────────────────────────────────────────

def anime_popular(page=1) -> dict:
    return _jikan('/top/anime', type='tv', filter='bypopularity', page=page)


def anime_airing(page=1) -> dict:
    """Currently airing seasonal anime."""
    return _jikan('/top/anime', type='tv', filter='airing', page=page)


def anime_seasonal(year: int = None, season: str = None) -> dict:
    """season = 'winter' | 'spring' | 'summer' | 'fall'"""
    import datetime
    if not year:
        year = datetime.date.today().year
    if not season:
        m = datetime.date.today().month
        season = ['winter', 'spring', 'summer', 'fall'][(m - 1) // 3]
    return _jikan(f'/seasons/{year}/{season}')


def anime_search(query: str, page=1) -> dict:
    return _jikan('/anime', q=query, type='tv', page=page, limit=20)


def anime_movies(page=1) -> dict:
    return _jikan('/top/anime', type='movie', page=page)


def anime_detail(mal_id: int) -> dict:
    return _jikan(f'/anime/{mal_id}/full')


def anime_episodes(mal_id: int, page=1) -> dict:
    return _jikan(f'/anime/{mal_id}/episodes', page=page)


def anime_genres() -> list:
    data = _jikan('/genres/anime')
    return data.get('data', [])


def anime_by_genre(genre_id: int, page=1) -> dict:
    return _jikan('/anime', genres=str(genre_id), type='tv',
                  order_by='popularity', page=page, limit=20)


# ── Data converters ──────────────────────────────────────────────────────────

def _entry_to_info(a: dict) -> dict:
    """Convert a Jikan anime entry to Kodi info labels."""
    titles = a.get('titles', [])
    title  = next((t['title'] for t in titles if t['type'] == 'English'), None)
    if not title:
        title = a.get('title', '')
    aired  = a.get('aired', {})
    year   = 0
    if aired.get('from'):
        try:
            year = int(aired['from'][:4])
        except Exception:
            pass
    genres = [g['name'] for g in a.get('genres', [])]
    return {
        'title':      title,
        'originaltitle': a.get('title_japanese', ''),
        'year':       year,
        'plot':       a.get('synopsis', ''),
        'rating':     a.get('score', 0),
        'votes':      str(a.get('scored_by', 0)),
        'genre':      ', '.join(genres),
        'status':     a.get('status', ''),
        'episode':    a.get('episodes') or 0,
        'mediatype':  'tvshow',
    }


def _entry_art(a: dict) -> dict:
    images = a.get('images', {})
    jpg    = images.get('jpg', {})
    webp   = images.get('webp', {})
    poster = webp.get('large_image_url') or jpg.get('large_image_url') or IMG_PLACEHOLDER
    thumb  = webp.get('image_url') or jpg.get('image_url') or IMG_PLACEHOLDER
    trailer_url = ''
    if a.get('trailer', {}).get('url'):
        trailer_url = a['trailer']['url']
    return {
        'poster': poster,
        'thumb':  thumb,
        'fanart': webp.get('large_image_url') or poster,
        'trailer': trailer_url,
    }


def get_english_title(a: dict) -> str:
    titles = a.get('titles', [])
    return (next((t['title'] for t in titles if t['type'] == 'English'), None)
            or a.get('title', 'Unknown'))


def get_results(data: dict) -> list:
    """Normalise Jikan response — top/search use 'data', seasonal uses 'data'."""
    return data.get('data', [])


def has_next_page(data: dict) -> bool:
    p = data.get('pagination', {})
    return p.get('has_next_page', False)


# ── AniList (for richer episode metadata when Jikan is thin) ─────────────────

_AL_EPISODES_QUERY = """
query ($id: Int, $page: Int) {
  Media(idMal: $id, type: ANIME) {
    episodes
    streamingEpisodes {
      title
      thumbnail
      url
      site
    }
    nextAiringEpisode {
      episode
      airingAt
    }
  }
}
"""


def anilist_episode_info(mal_id: int) -> dict:
    """Get streaming episode info from AniList for a given MAL ID."""
    return _anilist(_AL_EPISODES_QUERY, {'id': mal_id, 'page': 1})
