"""
lib/ui/player.py
Handles all playback:
  1. Check link cache (avoids re-scraping within 24hrs)
  2. Scrape + AllDebrid cache-check in parallel
  3. Show source chooser dialog (Umbrella-style)
  4. Resolve chosen source via AllDebrid
  5. Play via Kodi player
  6. Track progress at stop / on completion
"""

import json
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from lib.scrapers.engine    import scrape, LinkResult
from lib.resolvers.alldebrid import bulk_check_and_annotate, resolve_magnet, resolve_url
from lib.db.database         import Database
from lib.ui                  import metadata as tmdb

ADDON = xbmcaddon.Addon('plugin.video.vault')


# ── Source chooser dialog ─────────────────────────────────────────────────────

def _source_label(r: LinkResult) -> str:
    badge = '[COLOR limegreen][AD✓][/COLOR] ' if r.cached else ''
    res   = f'[{r.resolution.upper()}] ' if r.resolution else ''
    codec = f'{r.codec.upper()} ' if r.codec else ''
    hdr   = '[HDR] ' if r.hdr else ''
    size  = f'{r.size_gb:.1f}GB ' if r.size_gb else ''
    seeds = f'↑{r.seeds} ' if r.seeds else ''
    src   = f'[{r.source}]'
    return f'{badge}{res}{codec}{hdr}{size}{seeds}{src}'


def show_source_dialog(results: list[LinkResult]) -> LinkResult | None:
    if not results:
        xbmcgui.Dialog().notification('Vault', 'No sources found.',
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        return None
    labels = [_source_label(r) for r in results]
    idx = xbmcgui.Dialog().select('Choose Source', labels)
    if idx == -1:
        return None
    return results[idx]


# ── Progress monitor ──────────────────────────────────────────────────────────

class ProgressMonitor(xbmc.Player):
    """Monitors playback and writes progress to the database."""

    def __init__(self, tmdb_id, media_type, title, season=None, episode=None):
        super().__init__()
        self.tmdb_id    = tmdb_id
        self.media_type = media_type
        self.title      = title
        self.season     = season
        self.episode    = episode

    def _save(self):
        try:
            total    = self.getTotalTime()
            position = self.getTime()
            pct      = (position / total * 100) if total > 0 else 0
            with Database() as db:
                db.upsert_progress(
                    media_type=self.media_type,
                    tmdb_id=self.tmdb_id,
                    title=self.title,
                    season=self.season,
                    episode=self.episode,
                    progress_pct=pct,
                    duration_s=int(total),
                    position_s=int(position),
                )
            xbmc.log(f'[Vault] Saved progress {pct:.0f}% for {self.title}',
                     xbmc.LOGDEBUG)
        except Exception as e:
            xbmc.log(f'[Vault] Progress save error: {e}', xbmc.LOGWARNING)

    def onPlayBackStopped(self): self._save()
    def onPlayBackEnded(self):   self._save()
    def onPlayBackError(self):   self._save()


# ── Main Player class ─────────────────────────────────────────────────────────

class Player:
    def __init__(self, addon):
        self.addon = addon

    def _get_sources(self, query: dict, tmdb_id: int, media_type: str,
                     season=None, episode=None) -> list[LinkResult]:
        """Return ranked sources, using cache if fresh."""
        with Database() as db:
            cached_json = db.get_link_cache(tmdb_id, media_type,
                                             season=season, episode=episode)
        if cached_json:
            xbmc.log('[Vault] Using cached links', xbmc.LOGDEBUG)
            raw = json.loads(cached_json)
            return [LinkResult(**r) for r in raw]

        # Live scrape
        results = scrape(query)
        results = bulk_check_and_annotate(results)

        # Sort: cached first, then by score
        results.sort(key=lambda r: (r.cached, r.score), reverse=True)

        # Save to cache
        with Database() as db:
            db.set_link_cache(tmdb_id, media_type,
                              json.dumps([r.to_dict() for r in results]),
                              season=season, episode=episode)
        return results

    def play_movie(self, tmdb_id, title, year=''):
        tmdb_id = int(tmdb_id)
        imdb_id = tmdb.get_imdb_id(tmdb_id, 'movie')
        query   = {'type': 'movie', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id,
                   'title': title, 'year': str(year)}
        results = self._get_sources(query, tmdb_id, 'movie')

        # Check resume
        resume_pos = None
        if self.addon.getSetting('resume_enabled') == 'true':
            with Database() as db:
                prog = db.get_progress(tmdb_id, 'movie')
            if prog and prog.get('position_s', 0) > 30:
                choice = xbmcgui.Dialog().yesno(
                    'Resume', f'Resume from {int(prog["position_s"]//60)}m?',
                    nolabel='Start over', yeslabel='Resume'
                )
                if choice:
                    resume_pos = prog['position_s']

        chosen = show_source_dialog(results)
        if not chosen:
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            return

        stream_url = self._resolve(chosen)
        if not stream_url:
            xbmcgui.Dialog().notification('Vault', 'Could not resolve source.',
                                          xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            return

        li = xbmcgui.ListItem(path=stream_url)
        li.setInfo('video', {'title': title, 'mediatype': 'movie'})
        if resume_pos:
            li.setProperty('StartOffset', str(resume_pos))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)

        monitor = ProgressMonitor(tmdb_id, 'movie', title)
        # Monitor runs until playback ends
        while xbmc.Player().isPlaying():
            xbmc.sleep(5000)

    def play_episode(self, tmdb_id, title, season: int, episode: int):
        tmdb_id = int(tmdb_id)
        imdb_id = tmdb.get_imdb_id(tmdb_id, 'tvshow')
        query   = {'type': 'episode', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id,
                   'title': title, 'season': season, 'episode': episode}
        results = self._get_sources(query, tmdb_id, 'episode',
                                    season=season, episode=episode)

        chosen = show_source_dialog(results)
        if not chosen:
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            return

        stream_url = self._resolve(chosen)
        if not stream_url:
            xbmcgui.Dialog().notification('Vault', 'Could not resolve source.',
                                          xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            return

        ep_label = f'{title} S{season:02d}E{episode:02d}'
        li = xbmcgui.ListItem(path=stream_url)
        li.setInfo('video', {
            'title':        ep_label,
            'tvshowtitle':  title,
            'season':       season,
            'episode':      episode,
            'mediatype':    'episode',
        })
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)

        monitor = ProgressMonitor(tmdb_id, 'episode', title,
                                   season=season, episode=episode)
        while xbmc.Player().isPlaying():
            xbmc.sleep(5000)

        # Mark new-episode alert as seen if this was one
        with Database() as db:
            for ep in db.get_unseen_episodes():
                if (ep['tmdb_id'] == tmdb_id and
                        ep['season'] == season and ep['episode'] == episode):
                    db.mark_episode_seen(ep['id'])

    def _resolve(self, result: LinkResult) -> str:
        """Resolve a LinkResult to a direct stream URL."""
        try:
            if result.magnet or result.info_hash:
                magnet = result.magnet
                if not magnet and result.info_hash:
                    magnet = f'magnet:?xt=urn:btih:{result.info_hash}'
                return resolve_magnet(magnet, result.info_hash)
            elif result.url:
                return resolve_url(result.url)
            else:
                return ''
        except Exception as e:
            xbmc.log(f'[Vault] Resolve error: {e}', xbmc.LOGERROR)
            return ''
