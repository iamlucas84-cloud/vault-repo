"""
lib/ui/navigator.py
Builds all Kodi directory listings.
Mimics the Umbrella poster-grid aesthetic:
  - Large poster art
  - Fanart backgrounds
  - Watched overlay via playcount
  - "NEW" badge on unwatched new episodes
"""

import json
import xbmcgui
import xbmcplugin
from urllib.parse import urlencode

from lib.ui  import metadata as tmdb
from lib.db.database import Database

_WATCHED_OVERLAY = xbmcgui.ICON_OVERLAY_WATCHED
_UNWATCHED_OVERLAY = xbmcgui.ICON_OVERLAY_UNWATCHED


class Navigator:
    def __init__(self, handle: int, base_url: str, addon):
        self.handle   = handle
        self.base_url = base_url
        self.addon    = addon

    def _url(self, **params) -> str:
        return f'{self.base_url}?{urlencode(params)}'

    def _end(self, succeeded=True, cache=True):
        xbmcplugin.endOfDirectory(self.handle, succeeded=succeeded,
                                  cacheToDisc=cache)

    # ── Home ─────────────────────────────────────────────────────────────────

    def home(self):
        items = [
            ('🎬  Movies',           {'action': 'movies'}),
            ('📺  TV Shows',          {'action': 'tvshows'}),
            ('🎌  Anime',             {'action': 'anime'}),
            ('🕑  Watch History',     {'action': 'history'}),
            ('🔖  My Watchlist',      {'action': 'watchlist'}),
            ('🔔  New Episodes',      {'action': 'new_episodes'}),
            ('⚙️   Settings',          {'action': 'settings'}),
        ]
        xbmcplugin.setContent(self.handle, 'files')
        for label, params in items:
            li = xbmcgui.ListItem(label=label)
            li.setProperty('IsPlayable', 'false')
            xbmcplugin.addDirectoryItem(self.handle, self._url(**params), li, True)
        self._end()

    # ── Movies ───────────────────────────────────────────────────────────────

    def movies_menu(self):
        items = [
            ('Popular',       {'action': 'movies_popular'}),
            ('Trending Today',{'action': 'movies_trending'}),
            ('Search',        {'action': 'movies_search'}),
            ('By Genre',      {'action': 'movies_genres'}),
        ]
        xbmcplugin.setContent(self.handle, 'movies')
        for label, params in items:
            li = xbmcgui.ListItem(label=label)
            xbmcplugin.addDirectoryItem(self.handle, self._url(**params), li, True)
        self._end()

    def movies_list(self, category: str, page=1):
        if category == 'popular':
            data = tmdb.movie_popular(page)
        else:
            data = tmdb.movie_trending(page)
        self._build_movie_items(data.get('results', []))
        self._add_next_page(data, 'movies_list', category=category, page=page)
        self._end()

    def movies_list_by_genre(self, genre_id, genre_name, page=1):
        data = tmdb.movies_by_genre(int(genre_id), page)
        xbmcplugin.setPluginCategory(self.handle, genre_name)
        self._build_movie_items(data.get('results', []))
        self._add_next_page(data, 'movies_by_genre',
                            genre_id=genre_id, genre_name=genre_name, page=page)
        self._end()

    def _build_movie_items(self, movies: list):
        xbmcplugin.setContent(self.handle, 'movies')
        with Database() as db:
            for m in movies:
                tmdb_id = m['id']
                title   = m.get('title', '')
                year    = (m.get('release_date') or '')[:4]
                watched = db.is_watched(tmdb_id, 'movie')
                progress= db.get_progress(tmdb_id, 'movie')

                li = xbmcgui.ListItem(label=title)
                info = tmdb.movie_to_listitem_info(m)
                info['playcount'] = 1 if watched else 0
                li.setInfo('video', info)
                li.setArt({
                    'poster': tmdb.img(m.get('poster_path'),  'w342'),
                    'fanart': tmdb.img(m.get('backdrop_path'), 'w1280'),
                    'thumb':  tmdb.img(m.get('poster_path'),  'w342'),
                })
                if watched:
                    li.setOverlayImage(_WATCHED_OVERLAY)
                if progress and not watched:
                    li.setProperty('ResumeTime', str(progress.get('position_s', 0)))
                    li.setProperty('TotalTime',  str(progress.get('duration_s', 1)))

                li.addContextMenuItems([
                    ('Add to Watchlist',
                     f'RunPlugin({self._url(action="add_watchlist", tmdb_id=tmdb_id, title=title, media_type="movie")})'),
                    ('Mark as Watched',
                     f'RunPlugin({self._url(action="mark_watched", tmdb_id=tmdb_id, media_type="movie")})'),
                ])
                li.setProperty('IsPlayable', 'true')
                url = self._url(action='play_movie', tmdb_id=tmdb_id,
                                title=title, year=year)
                xbmcplugin.addDirectoryItem(self.handle, url, li, False)

    def movies_search(self):
        kb = xbmcgui.Dialog()
        query = kb.input('Search Movies', type=xbmcgui.INPUT_ALPHANUM)
        if not query:
            self._end(False); return
        data = tmdb.movie_search(query)
        self._build_movie_items(data.get('results', []))
        self._end()

    def movies_genres(self):
        genres = tmdb.movie_genres()
        xbmcplugin.setContent(self.handle, 'files')
        for g in genres:
            li = xbmcgui.ListItem(label=g['name'])
            url = self._url(action='movies_by_genre',
                            genre_id=g['id'], genre_name=g['name'])
            xbmcplugin.addDirectoryItem(self.handle, url, li, True)
        self._end()

    def movie_detail(self, tmdb_id, title):
        # For now just navigate straight to play — could add an info screen later
        xbmcplugin.setResolvedUrl(
            self.handle, False,
            xbmcgui.ListItem(label=title)
        )

    # ── TV Shows ──────────────────────────────────────────────────────────────

    def tvshows_menu(self):
        items = [
            ('Popular',  {'action': 'tvshows_popular'}),
            ('Search',   {'action': 'tvshows_search'}),
        ]
        xbmcplugin.setContent(self.handle, 'tvshows')
        for label, params in items:
            li = xbmcgui.ListItem(label=label)
            xbmcplugin.addDirectoryItem(self.handle, self._url(**params), li, True)
        self._end()

    def tvshows_list(self, category: str, page=1):
        data = tmdb.tvshow_popular(page)
        self._build_show_items(data.get('results', []))
        self._add_next_page(data, 'tvshows_popular', page=page)
        self._end()

    def _build_show_items(self, shows: list):
        xbmcplugin.setContent(self.handle, 'tvshows')
        for s in shows:
            tmdb_id = s['id']
            title   = s.get('name', '')
            li = xbmcgui.ListItem(label=title)
            li.setInfo('video', tmdb.tvshow_to_listitem_info(s))
            li.setArt({
                'poster': tmdb.img(s.get('poster_path'), 'w342'),
                'fanart': tmdb.img(s.get('backdrop_path'), 'w1280'),
            })
            li.addContextMenuItems([
                ('Add to Watchlist',
                 f'RunPlugin({self._url(action="add_watchlist", tmdb_id=tmdb_id, title=title, media_type="tvshow")})'),
            ])
            url = self._url(action='tvshow_seasons', tmdb_id=tmdb_id, title=title)
            xbmcplugin.addDirectoryItem(self.handle, url, li, True)

    def tvshows_search(self):
        query = xbmcgui.Dialog().input('Search TV Shows', type=xbmcgui.INPUT_ALPHANUM)
        if not query:
            self._end(False); return
        data = tmdb.tvshow_search(query)
        self._build_show_items(data.get('results', []))
        self._end()

    def tvshow_detail(self, tmdb_id, title):
        pass  # reserved for future info screen

    def tvshow_seasons(self, tmdb_id, title):
        detail = tmdb.tvshow_detail(int(tmdb_id))
        seasons = [s for s in detail.get('seasons', [])
                   if s.get('season_number', 0) > 0]
        xbmcplugin.setContent(self.handle, 'seasons')
        xbmcplugin.setPluginCategory(self.handle, title)
        for s in seasons:
            label = f'Season {s["season_number"]}'
            li = xbmcgui.ListItem(label=label)
            li.setInfo('video', {
                'title':       label,
                'tvshowtitle': title,
                'season':      s['season_number'],
                'episode':     s.get('episode_count', 0),
                'mediatype':   'season',
            })
            li.setArt({'poster': tmdb.img(s.get('poster_path'), 'w342')})
            url = self._url(action='tvshow_episodes', tmdb_id=tmdb_id,
                            title=title, season=s['season_number'])
            xbmcplugin.addDirectoryItem(self.handle, url, li, True)
        self._end()

    def tvshow_episodes(self, tmdb_id, title, season: int):
        data = tmdb.tvshow_season(int(tmdb_id), season)
        episodes = data.get('episodes', [])
        xbmcplugin.setContent(self.handle, 'episodes')
        xbmcplugin.setPluginCategory(self.handle, f'{title} — Season {season}')
        with Database() as db:
            for ep in episodes:
                ep_num  = ep['episode_number']
                ep_title= ep.get('name', f'Episode {ep_num}')
                watched = db.is_watched(int(tmdb_id), 'episode',
                                        season=season, episode=ep_num)
                label = f'{ep_num:02d}. {ep_title}'
                li = xbmcgui.ListItem(label=label)
                info = tmdb.episode_to_listitem_info(ep, title)
                info['playcount'] = 1 if watched else 0
                li.setInfo('video', info)
                li.setArt({
                    'thumb':  tmdb.img(ep.get('still_path'), 'w300'),
                    'fanart': tmdb.img(ep.get('still_path'), 'w780'),
                })
                if watched:
                    li.setOverlayImage(_WATCHED_OVERLAY)
                li.setProperty('IsPlayable', 'true')
                url = self._url(action='play_episode', tmdb_id=tmdb_id,
                                title=title, season=season, episode=ep_num)
                xbmcplugin.addDirectoryItem(self.handle, url, li, False)
        self._end()

    # ── History, Watchlist, Alerts ────────────────────────────────────────────

    def watch_history(self):
        xbmcplugin.setContent(self.handle, 'movies')
        with Database() as db:
            rows = db.get_history(limit=200)
        if not rows:
            li = xbmcgui.ListItem(label='No watch history yet.')
            xbmcplugin.addDirectoryItem(self.handle, '', li, False)
        for row in rows:
            label = row['title']
            if row['media_type'] == 'episode':
                label += f'  S{row["season"]:02d}E{row["episode"]:02d}'
            li = xbmcgui.ListItem(label=label)
            li.setInfo('video', {'title': label, 'mediatype': row['media_type']})
            xbmcplugin.addDirectoryItem(self.handle, '', li, False)
        self._end()

    def watchlist(self):
        xbmcplugin.setContent(self.handle, 'movies')
        with Database() as db:
            rows = db.get_watchlist()
        if not rows:
            li = xbmcgui.ListItem(label='Your watchlist is empty.')
            xbmcplugin.addDirectoryItem(self.handle, '', li, False)
        for row in rows:
            li = xbmcgui.ListItem(label=row['title'])
            if row['media_type'] == 'movie':
                url = self._url(action='play_movie', tmdb_id=row['tmdb_id'],
                                title=row['title'])
            else:
                url = self._url(action='tvshow_seasons', tmdb_id=row['tmdb_id'],
                                title=row['title'])
            xbmcplugin.addDirectoryItem(self.handle, url, li,
                                        row['media_type'] != 'movie')
        self._end()

    def new_episodes(self):
        xbmcplugin.setContent(self.handle, 'episodes')
        with Database() as db:
            rows = db.get_unseen_episodes()
        if not rows:
            li = xbmcgui.ListItem(label='No new episodes — you\'re all caught up!')
            xbmcplugin.addDirectoryItem(self.handle, '', li, False)
            self._end(); return
        for row in rows:
            label = (f'[COLOR orange][NEW][/COLOR] '
                     f'{row["show_title"]}  '
                     f'S{row["season"]:02d}E{row["episode"]:02d}'
                     + (f' — {row["ep_title"]}' if row.get('ep_title') else ''))
            li = xbmcgui.ListItem(label=label)
            li.setInfo('video', {
                'title':       row.get('ep_title', label),
                'tvshowtitle': row['show_title'],
                'season':      row['season'],
                'episode':     row['episode'],
                'mediatype':   'episode',
            })
            li.setProperty('IsPlayable', 'true')
            url = self._url(action='play_episode',
                            tmdb_id=row['tmdb_id'],
                            title=row['show_title'],
                            season=row['season'],
                            episode=row['episode'])
            xbmcplugin.addDirectoryItem(self.handle, url, li, False)
        self._end()

    # ── Utilities ─────────────────────────────────────────────────────────────

    def _add_next_page(self, data: dict, action: str, page: int, **extra):
        total = data.get('total_pages', 1)
        if page < total:
            li = xbmcgui.ListItem(label=f'Next Page ({page + 1} of {total})')
            url = self._url(action=action, page=page + 1, **extra)
            xbmcplugin.addDirectoryItem(self.handle, url, li, True)
