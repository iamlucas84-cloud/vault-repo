"""
lib/ui/anime_player.py
Anime playback handler.

Differences from the main player:
  - Uses anime_engine.scrape_anime() instead of the movie/TV engine
  - AnimeLink.is_direct = True items play immediately (no AllDebrid needed)
  - Source label shows Sub/Dub badge and Filler indicator
  - Uses media_type='anime_episode' in the watch history DB
"""

import json
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from lib.scrapers.anime_engine   import scrape_anime, AnimeLink
from lib.resolvers.alldebrid     import bulk_check_and_annotate, resolve_magnet, resolve_url
from lib.db.database             import Database

ADDON = xbmcaddon.Addon('plugin.video.vault')


# ── Source label ──────────────────────────────────────────────────────────────

def _source_label(r: AnimeLink) -> str:
    if r.is_direct:
        badge = '[COLOR deepskyblue][DIRECT][/COLOR] '
    elif r.cached:
        badge = '[COLOR limegreen][AD✓][/COLOR] '
    else:
        badge = ''

    sub_tag = ''
    if r.sub_type == 'sub':
        sub_tag = '[COLOR deepskyblue][Sub][/COLOR] '
    elif r.sub_type == 'dub':
        sub_tag = '[COLOR gold][Dub][/COLOR] '
    elif r.sub_type == 'raw':
        sub_tag = '[COLOR gray][Raw][/COLOR] '

    res   = f'[{r.resolution.upper()}] ' if r.resolution else ''
    size  = f'{r.size_gb:.1f}GB '        if r.size_gb   else ''
    seeds = f'↑{r.seeds} '               if r.seeds and not r.is_direct else ''
    src   = f'[{r.source}]'
    short_title = r.title[:60] + '…' if len(r.title) > 60 else r.title
    return f'{badge}{sub_tag}{res}{size}{seeds}{src}  {short_title}'


def show_anime_source_dialog(results: list) -> AnimeLink | None:
    if not results:
        xbmcgui.Dialog().notification('Vault Anime', 'No sources found.',
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        return None
    labels = [_source_label(r) for r in results]
    idx = xbmcgui.Dialog().select('Choose Anime Source', labels)
    return results[idx] if idx != -1 else None


# ── Progress monitor ──────────────────────────────────────────────────────────

class AnimeProgressMonitor(xbmc.Player):
    def __init__(self, mal_id: int, title: str, episode: int):
        super().__init__()
        self.mal_id  = mal_id
        self.title   = title
        self.episode = episode

    def _save(self):
        try:
            total    = self.getTotalTime()
            position = self.getTime()
            pct      = (position / total * 100) if total > 0 else 0
            with Database() as db:
                db.upsert_progress(
                    media_type='anime_episode',
                    tmdb_id=self.mal_id,
                    title=self.title,
                    season=1,
                    episode=self.episode,
                    progress_pct=pct,
                    duration_s=int(total),
                    position_s=int(position),
                )
            xbmc.log(f'[Vault/Anime] Saved progress {pct:.0f}% '
                     f'{self.title} E{self.episode:03d}', xbmc.LOGDEBUG)
        except Exception as e:
            xbmc.log(f'[Vault/Anime] Progress save error: {e}', xbmc.LOGWARNING)

    def onPlayBackStopped(self): self._save()
    def onPlayBackEnded(self):   self._save()
    def onPlayBackError(self):   self._save()


# ── Main player ───────────────────────────────────────────────────────────────

class AnimePlayer:
    def __init__(self, addon):
        self.addon = addon

    def play_episode(self, mal_id, title: str, episode: int):
        mal_id  = int(mal_id)
        episode = int(episode)

        # Check link cache
        with Database() as db:
            cached_json = db.get_link_cache(mal_id, 'anime_episode',
                                             season=1, episode=episode)
        if cached_json:
            xbmc.log('[Vault/Anime] Using cached links', xbmc.LOGDEBUG)
            raw     = json.loads(cached_json)
            results = [AnimeLink(**r) for r in raw]
        else:
            query   = {'title': title, 'mal_id': mal_id,
                       'episode': episode, 'type': 'series'}
            results = scrape_anime(query)

            # Bulk AllDebrid cache check (skip direct streams)
            torrent_results = [r for r in results if not r.is_direct]
            if torrent_results:
                torrent_results = bulk_check_and_annotate(torrent_results)
            direct_results  = [r for r in results if r.is_direct]
            results = direct_results + torrent_results

            # Resort: direct first, then cached, then by score
            results.sort(key=lambda r: (r.is_direct, r.cached, r.score), reverse=True)

            # Cache for next time
            with Database() as db:
                db.set_link_cache(
                    mal_id, 'anime_episode',
                    json.dumps([r.to_dict() for r in results]),
                    season=1, episode=episode
                )

        chosen = show_anime_source_dialog(results)
        if not chosen:
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            return

        stream_url = self._resolve(chosen)
        if not stream_url:
            xbmcgui.Dialog().notification(
                'Vault Anime', 'Could not resolve source.',
                xbmcgui.NOTIFICATION_ERROR, 4000
            )
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            return

        ep_label = f'{title} — E{episode:03d}'
        li = xbmcgui.ListItem(path=stream_url)
        li.setInfo('video', {
            'title':       ep_label,
            'tvshowtitle': title,
            'episode':     episode,
            'season':      1,
            'mediatype':   'episode',
        })
        # For m3u8 direct streams
        if stream_url.endswith('.m3u8') or 'manifest' in stream_url.lower():
            li.setMimeType('application/x-mpegURL')
            li.setContentLookup(False)

        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)

        _monitor = AnimeProgressMonitor(mal_id, title, episode)
        while xbmc.Player().isPlaying():
            xbmc.sleep(5000)

        # Dismiss new-episode alert if applicable
        with Database() as db:
            for ep in db.get_unseen_episodes():
                if (ep['tmdb_id'] == mal_id and ep['episode'] == episode):
                    db.mark_episode_seen(ep['id'])

    def _resolve(self, result: AnimeLink) -> str:
        """Resolve an AnimeLink to a direct URL."""
        # Direct stream — already a playable URL
        if result.is_direct and result.url:
            return result.url

        # AllDebrid torrent resolution
        try:
            if result.magnet or result.info_hash:
                magnet = result.magnet
                if not magnet and result.info_hash:
                    magnet = f'magnet:?xt=urn:btih:{result.info_hash}'
                return resolve_magnet(magnet, result.info_hash)
            elif result.url and not result.url.startswith('http'):
                return ''
            elif result.url:
                # Could be a torrent file URL — let AllDebrid handle it
                return resolve_url(result.url)
        except Exception as e:
            xbmc.log(f'[Vault/Anime] Resolve error: {e}', xbmc.LOGERROR)
        return ''
