"""
lib/ui/anime_navigator.py
Kodi directory listings for the Anime section.

Menu structure mirrors the Movies/TV navigator:
  Anime
  ├── Currently Airing        (Jikan top/airing)
  ├── Popular All Time        (Jikan top/bypopularity)
  ├── This Season             (Jikan seasonal)
  ├── Anime Movies            (Jikan top/movie)
  ├── Search                  (Jikan search)
  ├── By Genre
  ├── My Anime Watchlist
  └── New Episodes (Anime)    (unseen alerts for anime)

Each show → Seasons → Episodes → Play
  (episodes without a structured season use Episode 1..N directly)
"""

import xbmcgui
import xbmcplugin
from urllib.parse import urlencode

from lib.ui      import anime_metadata as jikan
from lib.db.database import Database

_WATCHED_OVERLAY   = xbmcgui.ICON_OVERLAY_WATCHED
_UNWATCHED_OVERLAY = xbmcgui.ICON_OVERLAY_UNWATCHED

# Colour tags for sub/dub badges in episode labels
SUB_COLOUR = 'deepskyblue'
DUB_COLOUR = 'gold'


class AnimeNavigator:
    def __init__(self, handle: int, base_url: str, addon):
        self.handle   = handle
        self.base_url = base_url
        self.addon    = addon

    def _url(self, **params) -> str:
        return f'{self.base_url}?{urlencode(params)}'

    def _end(self, succeeded=True, cache=True):
        xbmcplugin.endOfDirectory(self.handle, succeeded=succeeded,
                                  cacheToDisc=cache)

    # ── Top-level Anime menu ──────────────────────────────────────────────────

    def anime_menu(self):
        items = [
            ('📡  Currently Airing',      {'action': 'anime_airing'}),
            ('⭐  Popular All Time',       {'action': 'anime_popular'}),
            ('🗓️   This Season',            {'action': 'anime_seasonal'}),
            ('🎬  Anime Movies',           {'action': 'anime_movies'}),
            ('🔍  Search Anime',           {'action': 'anime_search'}),
            ('🏷️   Browse by Genre',        {'action': 'anime_genres'}),
            ('🔖  My Anime Watchlist',     {'action': 'anime_watchlist'}),
            ('🔔  New Anime Episodes',     {'action': 'anime_new_episodes'}),
        ]
        xbmcplugin.setContent(self.handle, 'tvshows')
        for label, params in items:
            li = xbmcgui.ListItem(label=label)
            li.setProperty('IsPlayable', 'false')
            xbmcplugin.addDirectoryItem(self.handle, self._url(**params), li, True)
        self._end()

    # ── Lists ─────────────────────────────────────────────────────────────────

    def anime_airing(self, page=1):
        xbmcplugin.setPluginCategory(self.handle, 'Currently Airing')
        data = jikan.anime_airing(page)
        self._build_anime_items(jikan.get_results(data))
        if jikan.has_next_page(data):
            self._add_next_page('anime_airing', page)
        self._end()

    def anime_popular(self, page=1):
        xbmcplugin.setPluginCategory(self.handle, 'Popular All Time')
        data = jikan.anime_popular(page)
        self._build_anime_items(jikan.get_results(data))
        if jikan.has_next_page(data):
            self._add_next_page('anime_popular', page)
        self._end()

    def anime_seasonal(self, page=1):
        xbmcplugin.setPluginCategory(self.handle, 'This Season')
        data = jikan.anime_seasonal()
        self._build_anime_items(jikan.get_results(data))
        self._end()

    def anime_movies(self, page=1):
        xbmcplugin.setPluginCategory(self.handle, 'Anime Movies')
        data = jikan.anime_movies(page)
        self._build_anime_items(jikan.get_results(data), is_movie=True)
        if jikan.has_next_page(data):
            self._add_next_page('anime_movies', page)
        self._end()

    def anime_search(self):
        query = xbmcgui.Dialog().input('Search Anime', type=xbmcgui.INPUT_ALPHANUM)
        if not query:
            self._end(False); return
        data = jikan.anime_search(query)
        self._build_anime_items(jikan.get_results(data))
        self._end()

    def anime_genres(self):
        genres = jikan.anime_genres()
        xbmcplugin.setContent(self.handle, 'files')
        xbmcplugin.setPluginCategory(self.handle, 'Anime Genres')
        for g in genres:
            li = xbmcgui.ListItem(label=g.get('name', ''))
            url = self._url(action='anime_by_genre',
                            genre_id=g['mal_id'],
                            genre_name=g.get('name', ''))
            xbmcplugin.addDirectoryItem(self.handle, url, li, True)
        self._end()

    def anime_by_genre(self, genre_id, genre_name, page=1):
        xbmcplugin.setPluginCategory(self.handle, genre_name)
        data = jikan.anime_by_genre(int(genre_id), page)
        self._build_anime_items(jikan.get_results(data))
        if jikan.has_next_page(data):
            self._add_next_page('anime_by_genre', page,
                                genre_id=genre_id, genre_name=genre_name)
        self._end()

    # ── Core list builder ─────────────────────────────────────────────────────

    def _build_anime_items(self, entries: list, is_movie=False):
        xbmcplugin.setContent(self.handle, 'tvshows' if not is_movie else 'movies')
        with Database() as db:
            for a in entries:
                mal_id  = a.get('mal_id')
                if not mal_id:
                    continue
                title   = jikan.get_english_title(a)
                info    = jikan._entry_to_info(a)
                art     = jikan._entry_art(a)

                # Watch state — use media_type='anime' to keep separate from TMDB TV
                watched = db.is_watched(mal_id, 'anime')
                info['playcount'] = 1 if watched else 0

                li = xbmcgui.ListItem(label=title)
                li.setInfo('video', info)
                li.setArt({
                    'poster': art['poster'],
                    'thumb':  art['thumb'],
                    'fanart': art['fanart'],
                })
                if watched:
                    li.setOverlayImage(_WATCHED_OVERLAY)

                li.addContextMenuItems([
                    ('Add to Anime Watchlist',
                     f'RunPlugin({self._url(action="anime_add_watchlist", mal_id=mal_id, title=title)})'),
                    ('Mark as Watched',
                     f'RunPlugin({self._url(action="anime_mark_watched", mal_id=mal_id)})'),
                ])

                if is_movie:
                    li.setProperty('IsPlayable', 'true')
                    url = self._url(action='anime_play_episode',
                                    mal_id=mal_id, title=title, episode=1)
                else:
                    url = self._url(action='anime_episodes',
                                    mal_id=mal_id, title=title)

                xbmcplugin.addDirectoryItem(self.handle, url, li, not is_movie)

    # ── Episode list ──────────────────────────────────────────────────────────

    def anime_episodes(self, mal_id, title, page=1):
        """List all episodes for an anime series."""
        mal_id = int(mal_id)
        data   = jikan.anime_episodes(mal_id, page)
        eps    = data.get('data', [])

        # If Jikan has no episode data, fall back to detail episode count
        if not eps:
            detail_data = jikan.anime_detail(mal_id)
            detail      = detail_data.get('data', {})
            ep_count    = detail.get('episodes') or 1
            eps = [{'mal_id': i, 'episode': i, 'title': f'Episode {i}',
                    'aired': '', 'score': 0.0}
                   for i in range(1, ep_count + 1)]

        xbmcplugin.setContent(self.handle, 'episodes')
        xbmcplugin.setPluginCategory(self.handle, title)

        with Database() as db:
            for ep in eps:
                ep_num   = ep.get('episode') or ep.get('mal_id', 1)
                ep_title = ep.get('title') or f'Episode {ep_num}'
                aired    = ep.get('aired') or ''
                watched  = db.is_watched(mal_id, 'anime_episode',
                                          season=1, episode=int(ep_num))
                label    = f'{int(ep_num):03d}. {ep_title}'
                li = xbmcgui.ListItem(label=label)
                li.setInfo('video', {
                    'title':       ep_title,
                    'tvshowtitle': title,
                    'season':      1,
                    'episode':     int(ep_num),
                    'aired':       aired,
                    'rating':      ep.get('score') or 0.0,
                    'playcount':   1 if watched else 0,
                    'mediatype':   'episode',
                })
                if ep.get('filler'):
                    li.setInfo('video', {'title': f'[Filler] {ep_title}'})
                if ep.get('recap'):
                    li.setInfo('video', {'title': f'[Recap] {ep_title}'})

                filler_badge = ' [COLOR gray][Filler][/COLOR]' if ep.get('filler') else ''
                recap_badge  = ' [COLOR gray][Recap][/COLOR]'  if ep.get('recap')  else ''
                watched_badge= ' [COLOR limegreen][✓][/COLOR]' if watched else ''
                li.setLabel(f'{label}{filler_badge}{recap_badge}{watched_badge}')

                if watched:
                    li.setOverlayImage(_WATCHED_OVERLAY)

                li.setProperty('IsPlayable', 'true')
                url = self._url(action='anime_play_episode',
                                mal_id=mal_id, title=title, episode=ep_num)
                xbmcplugin.addDirectoryItem(self.handle, url, li, False)

        # Next page of episodes
        if data.get('pagination', {}).get('has_next_page'):
            self._add_next_page('anime_episodes', page, mal_id=mal_id, title=title)

        self._end()

    # ── Watchlist & Alerts ────────────────────────────────────────────────────

    def anime_watchlist(self):
        xbmcplugin.setContent(self.handle, 'tvshows')
        xbmcplugin.setPluginCategory(self.handle, 'My Anime Watchlist')
        with Database() as db:
            rows = [w for w in db.get_watchlist() if w['media_type'] == 'anime']
        if not rows:
            li = xbmcgui.ListItem(label='Your anime watchlist is empty.')
            xbmcplugin.addDirectoryItem(self.handle, '', li, False)
        for row in rows:
            li  = xbmcgui.ListItem(label=row['title'])
            url = self._url(action='anime_episodes',
                            mal_id=row['tmdb_id'], title=row['title'])
            xbmcplugin.addDirectoryItem(self.handle, url, li, True)
        self._end()

    def anime_new_episodes(self):
        xbmcplugin.setContent(self.handle, 'episodes')
        xbmcplugin.setPluginCategory(self.handle, 'New Anime Episodes')
        with Database() as db:
            rows = [e for e in db.get_unseen_episodes()
                    if 'anime' in (e.get('media_type') or '')]
        if not rows:
            li = xbmcgui.ListItem(label='No new anime episodes — you\'re all caught up!')
            xbmcplugin.addDirectoryItem(self.handle, '', li, False)
            self._end(); return
        for row in rows:
            label = (f'[COLOR deepskyblue][NEW][/COLOR] '
                     f'{row["show_title"]}  '
                     f'E{row["episode"]:03d}'
                     + (f' — {row["ep_title"]}' if row.get('ep_title') else ''))
            li = xbmcgui.ListItem(label=label)
            li.setInfo('video', {
                'title':       row.get('ep_title', label),
                'tvshowtitle': row['show_title'],
                'episode':     row['episode'],
                'mediatype':   'episode',
            })
            li.setProperty('IsPlayable', 'true')
            url = self._url(action='anime_play_episode',
                            mal_id=row['tmdb_id'],
                            title=row['show_title'],
                            episode=row['episode'])
            xbmcplugin.addDirectoryItem(self.handle, url, li, False)
        self._end()

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _add_next_page(self, action: str, page: int, **extra):
        li  = xbmcgui.ListItem(label=f'Next Page ({page + 1} →)')
        url = self._url(action=action, page=page + 1, **extra)
        xbmcplugin.addDirectoryItem(self.handle, url, li, True)
