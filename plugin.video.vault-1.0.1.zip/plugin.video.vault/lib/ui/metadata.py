"""
lib/ui/metadata.py
Thin wrapper around the TMDB v3 API.
Returns dicts compatible with Kodi ListItem info labels.
Results are cached in memory for the session.
"""

import requests
import xbmcaddon

ADDON    = xbmcaddon.Addon('plugin.video.vault')
API_BASE = 'https://api.themoviedb.org/3'
IMG_BASE = 'https://image.tmdb.org/t/p/'

_cache: dict = {}


def _api(path: str, **params) -> dict:
    key = ADDON.getSetting('tmdb_api_key')
    cache_key = path + str(sorted(params.items()))
    if cache_key in _cache:
        return _cache[cache_key]
    r = requests.get(f'{API_BASE}{path}',
                     params={'api_key': key, 'language': 'en-US', **params},
                     timeout=10)
    r.raise_for_status()
    data = r.json()
    _cache[cache_key] = data
    return data


def img(path: str, size='w500') -> str:
    if not path:
        return ''
    return f'{IMG_BASE}{size}{path}'


# ── Movies ───────────────────────────────────────────────────────────────────

def movie_popular(page=1) -> dict:
    return _api('/movie/popular', page=page)


def movie_trending(page=1) -> dict:
    return _api('/trending/movie/day', page=page)


def movie_search(query: str, page=1) -> dict:
    return _api('/search/movie', query=query, page=page)


def movie_detail(tmdb_id: int) -> dict:
    return _api(f'/movie/{tmdb_id}',
                append_to_response='credits,videos,external_ids')


def movie_genres() -> list:
    return _api('/genre/movie/list').get('genres', [])


def movies_by_genre(genre_id: int, page=1) -> dict:
    return _api('/discover/movie', with_genres=genre_id,
                sort_by='popularity.desc', page=page)


def movie_to_listitem_info(m: dict) -> dict:
    return {
        'title':   m.get('title', ''),
        'year':    int((m.get('release_date') or '0')[:4] or 0),
        'plot':    m.get('overview', ''),
        'rating':  m.get('vote_average', 0),
        'votes':   str(m.get('vote_count', 0)),
        'genre':   ', '.join(g['name'] for g in m.get('genres', [])),
        'runtime': m.get('runtime', 0),
        'tagline': m.get('tagline', ''),
        'status':  m.get('status', ''),
        'mediatype': 'movie',
    }


# ── TV Shows ─────────────────────────────────────────────────────────────────

def tvshow_popular(page=1) -> dict:
    return _api('/tv/popular', page=page)


def tvshow_search(query: str, page=1) -> dict:
    return _api('/search/tv', query=query, page=page)


def tvshow_detail(tmdb_id: int) -> dict:
    return _api(f'/tv/{tmdb_id}',
                append_to_response='credits,external_ids,content_ratings')


def tvshow_season(tmdb_id: int, season: int) -> dict:
    return _api(f'/tv/{tmdb_id}/season/{season}')


def tvshow_to_listitem_info(s: dict) -> dict:
    return {
        'title':   s.get('name', ''),
        'year':    int((s.get('first_air_date') or '0')[:4] or 0),
        'plot':    s.get('overview', ''),
        'rating':  s.get('vote_average', 0),
        'genre':   ', '.join(g['name'] for g in s.get('genres', [])),
        'status':  s.get('status', ''),
        'mediatype': 'tvshow',
    }


def episode_to_listitem_info(ep: dict, show_title: str) -> dict:
    return {
        'title':    ep.get('name', ''),
        'tvshowtitle': show_title,
        'season':   ep.get('season_number', 0),
        'episode':  ep.get('episode_number', 0),
        'plot':     ep.get('overview', ''),
        'rating':   ep.get('vote_average', 0),
        'aired':    ep.get('air_date', ''),
        'mediatype':'episode',
    }


def get_imdb_id(tmdb_id: int, media_type='movie') -> str:
    """Fetch IMDb ID for Torrentio scraping."""
    if media_type == 'movie':
        data = _api(f'/movie/{tmdb_id}/external_ids')
    else:
        data = _api(f'/tv/{tmdb_id}/external_ids')
    return data.get('imdb_id', '')
