"""
Vault Video — plugin.video.vault
Entry point: routes URL calls from Kodi to the correct handler.
"""

import sys
from urllib.parse import parse_qsl, urlencode, urlparse

import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON    = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
HANDLE   = int(sys.argv[1])
BASE_URL = sys.argv[0]

# ── lazy imports (keep startup fast) ────────────────────────────────────────
def _nav():          from lib.ui.navigator       import Navigator;      return Navigator(HANDLE, BASE_URL, ADDON)
def _anime_nav():    from lib.ui.anime_navigator import AnimeNavigator; return AnimeNavigator(HANDLE, BASE_URL, ADDON)
def _player():       from lib.ui.player          import Player;         return Player(ADDON)
def _anime_player(): from lib.ui.anime_player    import AnimePlayer;    return AnimePlayer(ADDON)


def router(params: dict):
    action = params.get('action', 'home')

    if action == 'home':
        _nav().home()

    # ── Movies ───────────────────────────────────────────────────────────────
    elif action == 'movies':
        _nav().movies_menu()
    elif action == 'movies_popular':
        _nav().movies_list('popular', int(params.get('page', 1)))
    elif action == 'movies_trending':
        _nav().movies_list('trending', int(params.get('page', 1)))
    elif action == 'movies_search':
        _nav().movies_search()
    elif action == 'movies_genres':
        _nav().movies_genres()
    elif action == 'movies_by_genre':
        _nav().movies_list_by_genre(params['genre_id'], params['genre_name'],
                                    int(params.get('page', 1)))
    elif action == 'movie_detail':
        _nav().movie_detail(params['tmdb_id'], params['title'])

    # ── TV Shows ──────────────────────────────────────────────────────────────
    elif action == 'tvshows':
        _nav().tvshows_menu()
    elif action == 'tvshows_popular':
        _nav().tvshows_list('popular', int(params.get('page', 1)))
    elif action == 'tvshows_search':
        _nav().tvshows_search()
    elif action == 'tvshow_detail':
        _nav().tvshow_detail(params['tmdb_id'], params['title'])
    elif action == 'tvshow_seasons':
        _nav().tvshow_seasons(params['tmdb_id'], params['title'])
    elif action == 'tvshow_episodes':
        _nav().tvshow_episodes(params['tmdb_id'], params['title'],
                               int(params['season']))

    # ── Anime ─────────────────────────────────────────────────────────────────
    elif action == 'anime':
        _anime_nav().anime_menu()
    elif action == 'anime_airing':
        _anime_nav().anime_airing(int(params.get('page', 1)))
    elif action == 'anime_popular':
        _anime_nav().anime_popular(int(params.get('page', 1)))
    elif action == 'anime_seasonal':
        _anime_nav().anime_seasonal(int(params.get('page', 1)))
    elif action == 'anime_movies':
        _anime_nav().anime_movies(int(params.get('page', 1)))
    elif action == 'anime_search':
        _anime_nav().anime_search()
    elif action == 'anime_genres':
        _anime_nav().anime_genres()
    elif action == 'anime_by_genre':
        _anime_nav().anime_by_genre(params['genre_id'], params['genre_name'],
                                    int(params.get('page', 1)))
    elif action == 'anime_episodes':
        _anime_nav().anime_episodes(params['mal_id'], params['title'],
                                    int(params.get('page', 1)))
    elif action == 'anime_watchlist':
        _anime_nav().anime_watchlist()
    elif action == 'anime_new_episodes':
        _anime_nav().anime_new_episodes()

    # ── Anime playback ────────────────────────────────────────────────────────
    elif action == 'anime_play_episode':
        _anime_player().play_episode(
            params['mal_id'], params['title'], int(params['episode'])
        )

    # ── Anime watchlist mutations ─────────────────────────────────────────────
    elif action == 'anime_add_watchlist':
        from lib.db.database import Database
        with Database() as db:
            db.add_to_watchlist(int(params['mal_id']), 'anime', params['title'])
        xbmcgui.Dialog().notification(
            'Vault Anime', f'Added: {params["title"]}',
            xbmcgui.NOTIFICATION_INFO, 2500
        )
    elif action == 'anime_mark_watched':
        from lib.db.database import Database
        with Database() as db:
            db.upsert_progress('anime', int(params['mal_id']),
                               params.get('title', ''), progress_pct=100, watched=True)
        xbmcgui.Dialog().notification(
            'Vault Anime', 'Marked as watched', xbmcgui.NOTIFICATION_INFO, 2000
        )

    # ── Playback (Movies / TV) ────────────────────────────────────────────────
    elif action == 'play_movie':
        _player().play_movie(params['tmdb_id'], params['title'],
                             params.get('year', ''))
    elif action == 'play_episode':
        _player().play_episode(params['tmdb_id'], params['title'],
                               int(params['season']), int(params['episode']))

    # ── History / Watchlist ───────────────────────────────────────────────────
    elif action == 'history':
        _nav().watch_history()
    elif action == 'watchlist':
        _nav().watchlist()
    elif action == 'new_episodes':
        _nav().new_episodes()

    # ── Settings / Utilities ──────────────────────────────────────────────────
    elif action == 'settings':
        ADDON.openSettings()
    elif action == 'clear_cache':
        from lib.db.database import Database
        with Database() as db:
            db.purge_expired_cache()
        xbmcgui.Dialog().notification(
            'Vault', 'Cache cleared', xbmcgui.NOTIFICATION_INFO, 2000
        )
    else:
        xbmcgui.Dialog().notification(
            'Vault', f'Unknown action: {action}', xbmcgui.NOTIFICATION_ERROR
        )


if __name__ == '__main__':
    params = dict(parse_qsl(urlparse(sys.argv[2]).query))
    router(params)
