"""
script.vault.service / service.py
Background Kodi service that runs indefinitely.

Tasks (run once daily at midnight, or on Kodi start):
  1. Purge expired link cache entries
  2. Re-scrape and re-score link cache for watchlist items
  3. Check TMDB/TVDB for new episodes of shows the user has watched
  4. Show a Kodi notification if new episodes were found
  5. Trigger an addon.xml version bump for self-update checks
"""

import time
import json
import datetime
import requests

import xbmc
import xbmcaddon
import xbmcgui

ADDON    = xbmcaddon.Addon('script.vault.service')
MAIN     = xbmcaddon.Addon('plugin.video.vault')
API_BASE = 'https://api.themoviedb.org/3'

LOG_TAG  = '[VaultService]'


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'{LOG_TAG} {msg}', level)


def _tmdb(path, **params):
    key = MAIN.getSetting('tmdb_api_key')
    r = requests.get(f'{API_BASE}{path}',
                     params={'api_key': key, 'language': 'en-US', **params},
                     timeout=10)
    r.raise_for_status()
    return r.json()


def _today_str():
    return datetime.date.today().isoformat()


# ── Episode alert checker ─────────────────────────────────────────────────────

def check_new_episodes():
    """
    For every TV show the user has watched (plus watchlist TV entries),
    fetch the current season from TMDB and detect any episodes that
    aired since the user last watched the show.
    """
    log('Checking for new episodes...')
    from lib.db.database import Database

    new_count = 0
    today = _today_str()

    with Database() as db:
        watched_shows = db.get_watched_shows()
        watchlist     = [w for w in db.get_watchlist() if w['media_type'] == 'tvshow']

    # Merge, deduplicate
    shows = {s['tmdb_id']: s for s in watched_shows}
    for w in watchlist:
        shows[w['tmdb_id']] = {'tmdb_id': w['tmdb_id'], 'title': w['title']}

    for tmdb_id, show in shows.items():
        try:
            detail = _tmdb(f'/tv/{tmdb_id}')
            seasons = [s for s in detail.get('seasons', [])
                       if s.get('season_number', 0) > 0]
            latest_season = max((s['season_number'] for s in seasons), default=1)

            season_data = _tmdb(f'/tv/{tmdb_id}/season/{latest_season}')
            episodes = season_data.get('episodes', [])

            with Database() as db:
                for ep in episodes:
                    air_date = ep.get('air_date') or ''
                    ep_num   = ep['episode_number']
                    season_n = ep['season_number']

                    # Only consider episodes that have aired and aren't watched
                    if not air_date or air_date > today:
                        continue
                    already_watched = db.is_watched(
                        tmdb_id, 'episode',
                        season=season_n, episode=ep_num
                    )
                    if already_watched:
                        continue

                    # Not in new_episodes yet?
                    existing = [
                        e for e in db.get_unseen_episodes()
                        if (e['tmdb_id'] == tmdb_id and
                            e['season'] == season_n and
                            e['episode'] == ep_num)
                    ]
                    if not existing:
                        db.add_new_episode(
                            tmdb_id=tmdb_id,
                            show_title=show['title'],
                            season=season_n,
                            episode=ep_num,
                            air_date=air_date,
                            ep_title=ep.get('name', ''),
                        )
                        new_count += 1
                        log(f'New episode: {show["title"]} '
                            f'S{season_n:02d}E{ep_num:02d} ({air_date})')

            time.sleep(0.5)   # be polite to TMDB rate limits

        except Exception as e:
            log(f'Episode check error for tmdb_id={tmdb_id}: {e}', xbmc.LOGWARNING)

    log(f'Episode check done — {new_count} new episode(s) found.')
    return new_count


# ── Startup alert ─────────────────────────────────────────────────────────────

def check_new_anime_episodes():
    """
    For every anime series the user has watched at least one episode of,
    check Jikan for the total episode count and flag any episodes
    beyond what they've seen as new.
    """
    log('Checking for new anime episodes...')
    from lib.db.database import Database
    import requests

    JIKAN = 'https://api.jikan.moe/v4'
    sess  = requests.Session()
    sess.headers.update({'User-Agent': 'VaultKodi/1.0'})
    new_count = 0
    today = _today_str()

    # Find all anime the user has watched
    with Database() as db:
        history = db.get_history(media_type='anime_episode', limit=500)
        watchlist = [w for w in db.get_watchlist() if w['media_type'] == 'anime']

    shows: dict[int, str] = {}
    for row in history:
        shows[row['tmdb_id']] = row['title']
    for w in watchlist:
        shows[w['tmdb_id']] = w['title']

    for mal_id, show_title in shows.items():
        try:
            r = sess.get(f'{JIKAN}/anime/{mal_id}', timeout=10)
            detail = r.json().get('data', {})
            total_eps = detail.get('episodes') or 0
            status    = detail.get('status', '')

            # Only check airing shows — completed shows won't have new episodes
            if status not in ('Currently Airing', 'Not yet aired'):
                if total_eps > 0:
                    pass   # still check — user might be behind on completed show
                else:
                    continue

            with Database() as db:
                # Find highest episode the user has watched
                watched_eps = [
                    row for row in db.get_history(media_type='anime_episode', limit=1000)
                    if row['tmdb_id'] == mal_id
                ]
                max_watched = max((r['episode'] or 0 for r in watched_eps), default=0)

                # Try to get episode list to check air dates
                ep_r = sess.get(f'{JIKAN}/anime/{mal_id}/episodes',
                                params={'page': 1}, timeout=10)
                ep_data = ep_r.json()
                episodes = ep_data.get('data', [])

                for ep in episodes:
                    ep_num   = ep.get('episode', 0)
                    if not ep_num or int(ep_num) <= max_watched:
                        continue
                    air_date = ep.get('aired') or ''
                    # Skip episodes that haven't aired yet
                    if air_date and air_date[:10] > today:
                        continue
                    ep_title = ep.get('title') or f'Episode {ep_num}'
                    existing = [
                        e for e in db.get_unseen_episodes()
                        if e['tmdb_id'] == mal_id and e['episode'] == int(ep_num)
                    ]
                    if not existing:
                        db.add_new_episode(
                            tmdb_id=mal_id,
                            show_title=show_title,
                            season=1,
                            episode=int(ep_num),
                            air_date=air_date[:10] if air_date else '',
                            ep_title=ep_title,
                        )
                        new_count += 1
                        log(f'New anime episode: {show_title} E{int(ep_num):03d}')

            import time as _time
            _time.sleep(0.6)   # Jikan rate limit: ~3 req/s

        except Exception as e:
            log(f'Anime episode check error for mal_id={mal_id}: {e}', xbmc.LOGWARNING)

    log(f'Anime episode check done — {new_count} new episode(s) found.')
    return new_count



    if MAIN.getSetting('alert_startup') != 'true':
        return
    from lib.db.database import Database
    with Database() as db:
        unseen = db.get_unseen_episodes()
    if not unseen:
        return
    n = len(unseen)
    shows = list({ep['show_title'] for ep in unseen})[:3]
    show_str = ', '.join(shows) + ('...' if n > 3 else '')
    xbmcgui.Dialog().notification(
        'Vault — New Episodes',
        f'{n} new episode{"s" if n > 1 else ""}: {show_str}',
        xbmcgui.NOTIFICATION_INFO,
        8000
    )


# ── Cache refresh ─────────────────────────────────────────────────────────────

def refresh_watchlist_cache():
    """Pre-scrape links for all watchlist items so they play instantly."""
    from lib.db.database   import Database
    from lib.scrapers.engine import scrape
    from lib.resolvers.alldebrid import bulk_check_and_annotate
    from lib.ui import metadata as tmdb_meta

    with Database() as db:
        watchlist = db.get_watchlist()

    for item in watchlist:
        try:
            imdb_id = tmdb_meta.get_imdb_id(item['tmdb_id'], item['media_type'])
            query = {
                'type':    'movie' if item['media_type'] == 'movie' else 'show',
                'tmdb_id': item['tmdb_id'],
                'imdb_id': imdb_id,
                'title':   item['title'],
            }
            results = scrape(query)
            results = bulk_check_and_annotate(results)
            results.sort(key=lambda r: (r.cached, r.score), reverse=True)
            with Database() as db:
                db.set_link_cache(
                    item['tmdb_id'], item['media_type'],
                    json.dumps([r.to_dict() for r in results]),
                    ttl_hours=26   # slightly more than 24 to prevent gaps
                )
            log(f'Cache refreshed: {item["title"]}')
            time.sleep(1)
        except Exception as e:
            log(f'Cache refresh error for {item["title"]}: {e}', xbmc.LOGWARNING)


# ── Main service loop ─────────────────────────────────────────────────────────

class VaultService(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self._last_daily_run = None

    def _is_daily_due(self) -> bool:
        today = _today_str()
        return self._last_daily_run != today

    def _run_daily(self):
        log('Running daily tasks...')
        from lib.db.database import Database
        with Database() as db:
            db.purge_expired_cache()
        new_eps       = check_new_episodes()
        new_anime_eps = check_new_anime_episodes()
        if new_eps or new_anime_eps:
            show_startup_alert()
        refresh_watchlist_cache()
        self._last_daily_run = _today_str()
        log('Daily tasks complete.')

    def run(self):
        log('Service started.')
        # Run on startup
        time.sleep(10)          # wait for Kodi to fully settle
        show_startup_alert()    # show alerts from previous day's check
        if self._is_daily_due():
            self._run_daily()

        # Loop: check every hour if daily tasks are due
        while not self.abortRequested():
            if self.waitForAbort(3600):   # sleep 1 hour, wakes early on abort
                break
            if self._is_daily_due():
                self._run_daily()

        log('Service stopped.')


if __name__ == '__main__':
    VaultService().run()
